Place the 4(5eSpells, Expansion, ImprovedUI, and Patch3ModFixer) .PAK files in the Mods folder 
located C:\Users\[User]\AppData\Local\Larian Studios\Baldur's Gate 3\Mods

Replace the old modsettings.lsx with the new one
located C:\Users\[User]\AppData\Local\Larian Studios\Baldur's Gate 3\PlayerProfiles\[Player]

